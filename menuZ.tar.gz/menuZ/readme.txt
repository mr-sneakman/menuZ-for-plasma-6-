Please help i dont know what im doing i just wanted to get this nice widget working
with plasma 6 but now i've ended up ruining it with whatever ai told me to do.

I had no experience whatsoever with javascript so i have no clue what
anything thats in these files mean or what they do

linked is a copy of the actual menuz for plasma 5 https://store.kde.org/p/1367167/

please fix either this or that. all credit goes to the original creator
https://store.kde.org/u/adhe

Please fix either of these, i liked how it looked originally
